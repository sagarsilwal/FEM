
#include <gtest/gtest.h>

#include <parametrics/gmparametrics.h>
using namespace GMlib;

namespace {

  TEST(Parametrics, Dummy) {

    EXPECT_EQ( 1, 1 );
  }

}
