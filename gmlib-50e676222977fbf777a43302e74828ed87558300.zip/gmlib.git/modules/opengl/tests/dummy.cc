
#include <gtest/gtest.h>

#include <opengl/gmopengl.h>
using namespace GMlib;

namespace {

  TEST(OpenGL, Dummy) {

    EXPECT_EQ( 1, 1 );
  }

}
