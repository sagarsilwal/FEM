#include "gmevent.h"

using namespace GMlib;

Event::Event(double x) :
  _x(x) {
}
