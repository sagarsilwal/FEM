#include "gmsceneobjectattribute.h"
